# BUILD INSTRUCTIONS — Integrated Lecture Study Guide

> **Paste this whole file into the chat together with the lecture files and the
> `lecture_kit/` folder.** It is written for the agent, not for me. Follow it
> literally. Where it says MUST, it means MUST.

---

## 0. WHAT I AM GIVING YOU

| Slot | File | Role |
|---|---|---|
| **SLIDES** | a PDF of the lecture PowerPoint | **the spine.** Every slide becomes content. Nothing on a slide may be dropped. |
| **TRANSCRIPT** | a `.md` / `.txt` of the recorded lecture | **the voice.** Her explanations, exam hints, corrections, clinical stories, Q&A with students. |
| **BOOK** | a PDF excerpt of the textbook chapter | **the supplement.** Only what it adds beyond the slides. |
| **KIT** | the `lecture_kit/` folder | design system, scripts, this file. |

Any of the three sources may be missing for a given lecture — build with what exists.

> **Filenames lie.** Before anything else, open each PDF and check page count and
> page geometry. A landscape 960×540 PDF is the slide deck. A portrait PDF whose
> printed page numbers are in the 80s is the book excerpt. In the first lecture I
> sent, the file called `Anemia Integrated.pdf` was the PowerPoint and the file
> called `anemia.pdf` was the book — the opposite of what the names suggested.
> Say out loud which file is which before you start.

---

## 1. NON-NEGOTIABLE RULES

1. **Output language is ENGLISH**, always. The transcript is Egyptian Arabic mixed
   with English. **Translate her Arabic into English.** Keep her voice — she is
   direct, she uses factory/machine metaphors, she repeats things she wants
   remembered. Translate *that*, not a sanitised paraphrase.
2. **Act as a medical expert.** You are not transcribing, you are teaching. If she
   says something loosely, you still write it correctly — and you flag the gap
   (see §7).
3. **Nothing is lost.** Every slide, every book paragraph that adds something,
   every teaching sentence she said. If you decide something does not deserve a
   section, it still goes in a recall row, a table cell or an appendix.
4. **Drop room noise only**: attendance, greetings, "can we take the file?",
   "is the projector on?", "wake up doctors", off-topic jokes.
   **Keep**: her questions to students, students' answers, her corrections,
   exam hints, clinical anecdotes, analogies, self-corrections.
5. **Repeated content is TAGGED, never reprinted.** The second time a fact appears,
   write one line and a `<span class="chip c-rep">§6.4</span>` cross-reference.
   Collect all of them in the repeated-content index (§6, Appendix C).
6. **Label every fact with its source** using the chips: PPT / BOOK / DR.
7. **Images must never look like screenshots.** See §5.
8. **Draw every diagram the material deserves.** See §4.
9. **NO EMOJI ANYWHERE.** No emoji font exists in the sandbox; they render as
   blank boxes or crash the layout. Callout icons are CSS squares. Plain symbols
   are fine: `↑ ↓ → · — ≤ ≥ × ² ⁺ α β γ δ µ`.

---

## 2. PIPELINE — run in this order

### Step 0 · Setup (every session)
Work from the **project root** — the folder that *contains* `lecture_kit/`.
All paths in the CSS and the scripts are relative to it.
```bash
bash lecture_kit/scripts/setup.sh
```
Installs `weasyprint pymupdf pillow fonttools`, downloads **Source Serif 4** and
**Source Sans 3** as variable fonts and freezes them to static instances in
`fonts/`.
*Sandbox installs do not survive between sessions — if any later step dies with
`ModuleNotFoundError`, re-run this and continue.*

### Step 1 · Extract
```bash
python3 lecture_kit/scripts/extract.py uploads/SLIDES.pdf uploads/BOOK.pdf
```
Produces `out/ppt_text.txt`, `out/book_text.txt`, every embedded image in
`assets/`, and contact sheets `out/contact_*.png`.

### Step 2 · READ EVERYTHING — before writing one line
- Read the **entire** transcript, top to bottom. Not a skim.
- Read every slide's text.
- Read every book page.
- **Look at** `out/contact_*.png` with the image tool and decide which images are
  usable, which are collages that must be split, which are too low-resolution.

Then write a plan and show it to me: the chapter list, which slides map to which chapter, which
diagrams you will draw, which figures you will keep.

### Step 3 · Write the chapters
Copy `template/00_head.html` to `src/00_head.html`, replace the three
placeholders, then write the chunks (§3). **One file per chapter**, written with
`write_file`, never by appending blindly.

### Step 4 · Build and proof
```bash
GUIDE_NAME="The_Topic_Study_Guide" python3 lecture_kit/scripts/build.py
```
Then **read every `out/sheet*.png`** with the image tool. Fix defects. Rebuild.
This proof loop is mandatory — it is how the layout bugs in §8 were caught.

### Step 5 · Flashcards
Write `cards_config.json` (shape documented at the top of the script), then:
```bash
python3 lecture_kit/scripts/make_cards.py
python3 -c "from weasyprint import HTML; HTML('flashcards.html', base_url='.').write_pdf('The_Topic_Flashcards.pdf')"
GUIDE_NAME="The_Topic_Study_Guide" python3 lecture_kit/scripts/build.py
```
The last command re-renders the guide so the flashcard appendix is inside it.

### Step 6 · Deliver
`present_file` the guide. Mention the flashcard PDF and the TSV by name.

---

## 3. DOCUMENT STRUCTURE — fixed

| File | Contents |
|---|---|
| `src/00_head.html` | the design system. **Never restyle it.** Copy from `template/`. |
| `src/01_front.html` | cover page + "How to use this guide" (source tags, the four callout boxes, the Learn→Do rhythm, a note that figures were rebuilt not screenshotted) |
| `src/02_map.html` | **one full-page SVG mind map** of the whole lecture |
| `src/10_ch1.html` … `src/19_chN.html` | the chapters, in lecture order |
| `src/20_appendix.html` | Appendix A one-page master grid · Appendix B "Everything She Flagged for the Exam" · Appendix C source map + book-only extras + repeated-content index |
| `src/21_contradictions.html` | **Appendix D — Where the Sources Disagree** (§7) |
| `src/9_flashcards.html` | Appendix E — generated, always last |

### Every chapter follows the same rhythm
```html
<div class="chapopen">
  <span class="chapnum">Chapter Six · Inadequate Production</span>
  <h1 class="chap">Iron Deficiency Anemia</h1>
  <p class="chapsub">slides 10–15 · book pp. 84–85 · her longest teaching block</p>
</div>

<div class="band"><span>Learn</span></div>
   ... definition box, keystrip, prose, tables, figures, SVG diagrams,
       callouts (.dr / .exam / .clin / .bookx / .note / .warn), mnemonic ...

<div class="band do"><span>Do</span></div>
   ... "She asked the class" boxes (her real in-class questions + the answer)
   ... 2–4 exam-style MCQs in .q / .qh / .qb / .opts
   ... a <div class="recall"> rapid-recall table  (prompt | answer)
   ... <div class="answers"> answer key with one line of reasoning each
```

`h1.chap` sets the running header via `string-set: chaptitle`.
**MUST NOT** add a named `@page` for chapter openers — see §8.

---

## 4. DIAGRAMS — hand-drawn inline SVG

Every diagram is **inline `<svg>`**, written by you, with `viewBox="0 0 1000 H"`
and `width:100%` so it scales to the 171 mm text column. Use font-family
`SSans`. Never screenshot a slide's diagram; rebuild it.

Draw one whenever the material has a **structure** a paragraph cannot carry:
classification trees, timelines, algorithms, see-saws/balances, escalation
ladders, comparison splits, clue maps, lineage diagrams, value charts.

In the anemias lecture these were drawn — use the same vocabulary of forms:

| Diagram | Form |
|---|---|
| Master mind map | radial hub with four branch groups |
| Haemoglobin types | three chain-composition cards + a percentage switch bar |
| Age groups | horizontal timeline with labelled bands |
| Etiological classification | left-to-right tree, colour per branch |
| Morphological classification | tree from the CBC indices |
| CBC → diagnosis | decision algorithm with diamond splits |
| General symptoms | 10-cell icon grid (CSS/SVG shapes, **not** emoji) |
| Physiologic anemia | see-saw: oxygen up ⇄ erythropoietin down |
| Hb nadir | plotted line chart, term vs preterm, with the nadir marked |
| Iron metabolism | flow: intake → absorption → transport → storage → utilisation |
| Investigation order | numbered sequence strip showing what falls first |
| Lead chelation | **ladder**, rungs ascending low → high |
| Treatment escalation | stepped blocks with the definitive step highlighted |
| Pancytopenia | one stem cell → three lineages → three symptom sets |
| A vs B discriminator | split panel, shared features in the middle, differences on the wings |
| Exam case | clue-by-clue rows: phrase on the left, what it proves on the right |
| Investigation choice | A/B/C/D options with a "why C" panel |

**SVG rules (learned the hard way):**
- `radialGradient` **does not render** in WeasyPrint — silently produces nothing.
  Use `linearGradient` or flat fills with `fill-opacity`.
- Set explicit `font-family="SSans"` on every `<text>`.
- Wrap each in `<div class="diag"><div class="dtitle">…</div> SVG <div class="dcap">…</div></div>`.

---

## 5. FIGURES — professional treatment, never screenshots

1. Extract at **native resolution** from the slide deck (`extract.py` does this).
2. **Split collages.** A slide showing four clinical photos in one bitmap must be
   cut into four separate figures with PIL crops.
3. **Crop out** slide borders, watermarks, leftover captions, arrows baked into
   the bitmap.
4. Normalise: straighten, colour-correct, trim to a consistent aspect.
5. Save to `fig/` as **`.jpg` quality 90, `subsampling=0`** — not PNG. Photographs
   as PNG roughly quintuple the file size for no visual gain. Keep PNG only for
   line art with hard edges.
6. Re-caption every figure yourself in the house style — a bold lead-in and one
   clinical sentence. Wrap in `<figure>` inside `.figrow` (two-up) or `.figfull`.
7. **Drop anything you cannot label confidently.** In the anemias lecture one
   panel of a four-panel figure could not be identified; it was left out rather
   than guessed.
8. If a source image is tiny (≈80–100 px), display it small (≈35 mm) so it does
   not look upscaled.

---

## 6. THE APPENDICES

- **Appendix A — One-page master grid.** Every disease in the lecture × group /
  age / morphology / reticulocytes / key clues / treatment. One page, landscape
  feel, dense.
- **Appendix B — Everything She Flagged for the Exam.** A numbered table of every
  point she marked as examinable, each with the § where it lives and *why* she
  flagged it.
- **Appendix C — Source map & repeated-content index.** Three parts: (1) a
  slide → chapter table with notes; (2) what the book adds beyond the slides,
  quoted; (3) the repeated-content index — every fact that recurs, where it is
  printed in full, and where it is tagged.
- **Appendix D — Where the sources disagree.** See §7.
- **Appendix E — Flashcards.** Generated.

---

## 7. THE CONTRADICTION REGISTER — Appendix D · MANDATORY

**This step is not optional and it is easy to skip. Do not skip it.**

Three sources describing the same material will not agree everywhere. My exam is
marked against the printed material, so I need to know exactly where they diverge
and what to write.

### 7.1 How to find the contradictions — do all four passes

1. **PPT vs BOOK — mechanical diff.** Extract every number-bearing phrase from
   both and diff the sets:

```python
import re
ppt = open('out/ppt_text.txt', encoding='utf-8').read()
bk  = open('out/book_text.txt', encoding='utf-8').read()
def facts(t):
    pat = r'[^\n.;]{0,70}?\b(\d+[\d\u2013\u2212-]*\s*(?:g/dL|fL|%|µg/dL|mg/kg|months?|weeks?|years?|lobes))'
    return {re.sub(r'\s+',' ',m.group(0)).strip() for m in re.finditer(pat, t, re.I)}
a, b = facts(ppt), facts(bk)
print('ONLY IN PPT:',  *sorted(a - b), sep='\n  ')
print('ONLY IN BOOK:', *sorted(b - a), sep='\n  ')
```

2. **PPT vs ITSELF.** Slide bodies vs summary/comparison tables on later slides.
   This is where the anemias deck contradicted itself (4–5 months on slide 38,
   4–6 months in the table on slide 41).

3. **TRANSCRIPT vs PRINTED.** Grep the transcript for every number, inheritance
   pattern, drug, age and percentage and check each against the slide:

```bash
grep -nEi "[0-9]+ ?(g/dl|fl|%|month|year|week|mg|µg)|dominant|recessive|autosom|parvo" TRANSCRIPT.md
```

4. **TRANSCRIPT vs ITSELF.** She teaches a point correctly, then rushes a recap
   and says the opposite. Both instances must be found. In the anemias lecture
   she said pernicious anemia was *autosomal recessive* while teaching the slide
   and *autosomal dominant* twenty minutes later in the comparison table.

### 7.2 Classify every hit

- **Real conflict** — two sources assert different facts. Goes in **D.1** with a
  verdict.
- **Source self-contradiction** — the same document says both. Goes in **D.1**,
  verdict = "neither can be marked wrong; write the one that contains the other."
- **Looser speech** — she rounded, extended or compressed. **Not a conflict.**
  Goes in **D.2** with "what to write".
- **Layout/printing fault** — e.g. she said "I don't know why all the tables are
  reversed, this one should be the other way round." Note it, and **fix it in
  your redrawn diagram**.

### 7.3 Where each one appears — twice

1. **Inline, at the point of use**, as a `<div class="box warn">` headed
   *"Careful — …"*, so a student reading the chapter cannot miss it.
2. **Again in Appendix D**, in a four-row table: *source A · source B · she said ·
   verdict*, each cross-linked back with `<span class="chip c-rep">§12.5</span>`.

Close Appendix D with a one-line summary box listing only the safe answers.

### 7.4 Tone
Never say she was wrong. Say *"the recap was the slip, not the teaching"*, or
*"her first sentence was the slip and she caught it"*. Where she self-corrected,
**say that she self-corrected** — it is a point in her favour and it tells me the
correction is deliberate.

---

## 8. TRAPS — every one of these has already cost a rebuild

| Trap | Rule |
|---|---|
| **Emoji** | none exist. Never use one. |
| `import fitz` | deprecated — `import pymupdf`. |
| Named `@page` on a chapter opener | `h1.chap { page: chapter-open }` + `break-before: page` emits a **spurious blank page** before every chapter. Do not reintroduce it. The template has no named page except `cover`. |
| `radialGradient` in SVG | renders as nothing in WeasyPrint. Linear only. |
| Variable fonts | unreliable in WeasyPrint. Always use the static instances from `setup.sh`. |
| Google Fonts filenames | download URL-encoded (`%5Bwght%5D`) — rename before use. |
| `cat src/*.html` | **wrong order** once `2*.html` exists. Use `scripts/build.py`. |
| `dotted` / `dashed` CSS borders on a repeated element | WeasyPrint emits every dot as a separate path. 175 small cards with one dotted rule each took the PDF from **3 MB to 6 MB**. Use `solid` hairlines. |
| `display:flex` on a text container | inline `<b>` and `<i>` become **flex items** — words lose their spaces and bold text jumps to its own column. Always put the text in an inner `<div>`. |
| `table { break-inside: avoid }` | pushes long tables whole onto the next page and leaves half-empty pages. Use `break-inside: auto` on `table`, `avoid` on `tr`, and `break-after: avoid` on `caption`. |
| Photographs as PNG | ~5× the size. JPEG q90, `subsampling=0`. |
| Delivering without proofing | always read `out/sheet*.png` first. |

---

## 9. DEFINITION OF DONE

- [ ] Every slide accounted for in Appendix C's slide → chapter map.
- [ ] Every teaching sentence in the transcript used or deliberately classified as noise.
- [ ] Book-only additions quoted in Appendix C.
- [ ] Every chapter has Learn **and** Do, with her real questions, 2–4 MCQs, a recall table and an answer key.
- [ ] Every repeated fact tagged, not reprinted, and listed in the repeated-content index.
- [ ] All planned SVG diagrams drawn; no screenshotted diagram anywhere.
- [ ] Figures split, cleaned, captioned, saved as JPEG.
- [ ] **Appendix D written, with all four contradiction passes actually run.**
- [ ] Flashcards generated; appendix is the last section of the guide.
- [ ] Contact sheets read; no near-empty pages, orphaned headings or overflow.
- [ ] File size sane (< ~90 KB/page).
- [ ] Guide presented; companion files named.

---

## 10. WHAT TO TELL ME AT THE END

A short message, no wall of text:
1. Page count and file size.
2. What is inside, in three or four bullets.
3. **The contradictions you found, with the verdicts** — this is the part I care
   about most.
4. The names of the companion files.
