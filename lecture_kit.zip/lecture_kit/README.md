# Lecture Study-Guide Kit

**What this is:** everything needed to reproduce the same study guide, with the
same design, fonts, tools, diagrams and method, for any new lecture.

---

## For me — what I do each time

1. Start a new chat.
2. Attach:
   - the **lecture PowerPoint** (as PDF)
   - the **transcript** of the recording (`.md` or `.txt`)
   - the **textbook pages** (as PDF) — optional
   - this whole **`lecture_kit/`** folder
3. Paste **`PASTE_THIS.md`** as my message, filling in the four blanks at the top.

That is all. Everything else is in the kit.

> If I only have the slides, or only the slides + transcript, it still works —
> the agent builds with what exists.

---

## What is in the folder

| File | Purpose |
|---|---|
| `PASTE_THIS.md` | **the message I paste.** Short. Fill in 4 blanks. |
| `INSTRUCTIONS.md` | the full build spec the agent follows — pipeline, rules, traps, definition of done. |
| `DESIGN_SYSTEM.md` | the component reference: palette, type, every CSS class, SVG conventions. |
| `template/00_head.html` | the actual design system. Copied to `src/` and used verbatim. |
| `scripts/setup.sh` (run from the project root) | installs the tools, downloads and freezes the fonts. |
| `scripts/extract.py` | pulls text + images out of the PDFs, builds contact sheets. |
| `scripts/build.py` | concatenates, renders, compresses, and makes proof sheets. |
| `scripts/make_cards.py` | builds the flashcards: in-guide appendix, cut-out deck, Anki file. |

---

## What comes out

| Deliverable | Shape |
|---|---|
| `<Topic>_Study_Guide.pdf` | A4. Cover · how-to-use · full-page mind map · one chapter per topic, each Learn → Do · Appendix A master grid · B exam points · C source map · **D where the sources disagree** · E flashcards. |
| `<Topic>_Flashcards.pdf` | Cut-out deck, 12 per sheet, duplex-mirrored. |
| `<Topic>_anki.tsv` | Same cards, tagged, for Anki. |

---

## Verified
The kit was run end-to-end from an empty folder before being handed over:
`setup.sh` → fonts installed · `make_cards.py` → deck + appendix + TSV ·
`build.py` → rendered A4 PDF with cover, running headers, Learn/Do chapter,
warning box, recall table and the flashcard appendix in the right place.

## The three things that make it work

1. **Read everything first.** Whole transcript, every slide, every book page, and
   actually *look* at the extracted images — before writing a line.
2. **Learn → Do in every chapter.** Teach it, then test it: her real in-class
   questions, MCQs, a rapid-recall table, an answer key.
3. **Appendix D.** Run all four contradiction passes (PPT vs book, PPT vs itself,
   transcript vs printed, transcript vs itself). This is the step most likely to
   be skipped and the one I care about most.
