Build me an integrated A4 study guide for this lecture, exactly the way the
`lecture_kit` specifies.

**Lecture:** _______________________________________
**Doctor:** ________________________________________
**Department / University:** _______________________
**Scope / what is NOT in this lecture:** ___________

**Files attached**
- SLIDES (the PowerPoint, as PDF): `____________`
- TRANSCRIPT (recording, Arabic/English): `____________`
- BOOK (textbook pages, PDF): `____________`   ← may be absent
- `lecture_kit/` — the design system, scripts and the build spec

---

**Read `lecture_kit/INSTRUCTIONS.md` first and follow it literally.**
`lecture_kit/DESIGN_SYSTEM.md` is the component reference — compose from it, do
not restyle it.

The short version of what I want, so you can sanity-check yourself against it:

1. **Built around the slides** as the spine. Add her highlights, additions, exam
   points and clinical mentions from the transcript. Add what the book has that
   the slides do not.
2. **Nothing changed, nothing missed, nothing deleted.** Repeated information is
   **tagged** with a cross-reference, never reprinted.
3. **All English.** Translate her Arabic, keep her voice.
4. **Act as a medical expert**, not a transcriber.
5. **Learn → Do in every chapter.** The Do half = her own in-class questions +
   2–4 MCQs + a rapid-recall table, all with answers.
6. **Every image professionally rebuilt** — cropped, split out of collages,
   de-watermarked, re-captioned. Nothing may look like a pasted screenshot.
7. **Draw every diagram and mind map the material deserves**, as inline SVG in
   the house style.
8. **Label every fact** PPT / BOOK / DR.
9. **Appendix D — where the sources disagree.** Run all four contradiction
   passes in §7 of the instructions. Flag each one inline *and* in the appendix,
   with a verdict telling me what to write in the exam. Do not skip this.
10. **Flashcards as the last appendix**, plus the cut-out deck and the Anki file.

Proof the contact sheets before you deliver, and end with a short message: page
count, what is inside, **the contradictions you found and their verdicts**, and
the names of the companion files.
