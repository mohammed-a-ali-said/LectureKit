# DESIGN SYSTEM — component reference

Everything here is already implemented in `template/00_head.html`.
**Do not restyle it, do not invent new classes.** Compose from this vocabulary.
If a new block type is genuinely needed, add it in the same idiom and record it
here.

---

## Page

- **A4**, margins `19 / 16 / 17 / 16 mm` → text column **171 mm** wide.
- Running header: left = `{{RUNNING_HEAD}}` (the short lecture name, caps,
  letterspaced), right = current chapter title via `string-set: chaptitle`.
- Footer: left = `{{FOOTER_LINE}}` (doctor · department · university),
  right = page number in crimson.
- Only one named page exists: `@page cover`. **Never add another** (see the
  blank-page trap).

## Type

| Role | Face | Size |
|---|---|---|
| Body | Source Serif 4 (`SSerif`), DejaVu Serif fallback | 10.1 pt / 1.52 |
| Headings, labels, tables, SVG text | Source Sans 3 (`SSans`) | varies |
| Tables | `SSans` | 9.1 pt |

Static instances only, from `fonts/`. Serif is pinned to `opsz=11`.

## Palette

| Token | Hex | Tint | Used for |
|---|---|---|---|
| `--crimson` | `#9B1B30` | `#FBEFF1` / `#EFCAD1` | primary, chapter rules, "The doctor said" |
| `--crimson-dk` | `#6E1222` | — | cover gradient, case chapter |
| `--navy` | `#14324F` | `#EEF3F8` / `#C6D6E6` | PPT chip, structure |
| `--teal` | `#0E6B66` | `#EBF6F4` / `#BFE0DB` | clinical mention |
| `--amber` | `#9A6A06` | `#FFF7E4` / `#E2C171` | exam point |
| `--indigo` | `#463C8C` | `#F1F0FA` / `#CFCAEA` | book extra |
| `--slate` | `#5A6472` | — | captions, small caps labels |
| `--rule` | `#DCE2E9` | — | hairlines |
| `--ink` | `#1B2230` | — | body text |

SVG-only extras: `#A0522D` `#1F5A7D` `#5A6472` `#A93A22`.
High-yield badge: `#D9A521`.

## Source chips — put one on every fact

```html
<span class="chip c-ppt">PPT 13</span>     <!-- navy   — from the slides -->
<span class="chip c-book">BOOK p.85</span> <!-- indigo — from the textbook -->
<span class="chip c-dr">DR</span>          <!-- crimson— she said it, it is not printed -->
<span class="chip c-rep">§6.4</span>       <!-- grey   — repeated, cross-reference only -->
```

## Callout boxes

```html
<div class="box dr">   <span class="hd">The doctor said</span>   …her explanation, translated
<div class="box exam"> <span class="hd">Exam point</span>        …she flagged this explicitly
<div class="box clin"> <span class="hd">Clinical mention</span>  …ward behaviour, what to do next
<div class="box bookx"><span class="hd">Book extra</span>        …in the book, not on the slide
<div class="box note"> <span class="hd">Note</span>              …neutral aside
<div class="box warn"> <span class="hd">Careful — …</span>       …CONTRADICTIONS ONLY
```

Variant for her questions to the class:
```html
<div class="box dr" style="border-left-color:#B9899A;background:#FAF5F6">
  <span class="hd">She asked the class</span> …
```

The icon is a CSS `:before` square. **Never an emoji.**

## Structural blocks

| Class | Use |
|---|---|
| `.chapopen` + `.chapnum` + `h1.chap` + `.chapsub` | chapter opener |
| `.band` / `.band.do` | the LEARN and DO dividers |
| `.lede` | the italic opening paragraph of a chapter |
| `.keystrip` + `.k` (`.lbl` `.val` `.cap`) | 3–4 headline numbers in a row |
| `.diag` + `.dtitle` + `.dcap` | wrapper for an inline SVG diagram |
| `.figrow` + `<figure>` | two figures side by side |
| `.figfull` | one full-width figure |
| `.imgpad` | padding for a figure that would otherwise bleed |
| `.mnemo` + `.word` | mnemonic strip |
| `.said` | a pull-quote of her words |
| `.mini` | small-caps inline label |
| `.twocol` | two equal text columns |
| `ol.alpha`, `ul.dash` | lettered / dashed lists |
| `table.tight`, `table.crim`, `.rowh`, `.c` | tables; `.crim` = comparison table |
| `.q` `.qh` `.qb` `.opts` | one MCQ |
| `.recall` (+ `.rh`) | rapid-recall table, two columns: prompt \| answer |
| `.answers` | answer key block |
| `.pagebreak` | forced break, use sparingly |
| `.fcwrap` `.fcsec` `.fc` `.fcq` `.fca` `.fcnum` `.fcstar` | flashcard appendix (generated) |

## Break behaviour — already set, do not fight it

```css
table { break-inside: auto }    tr { break-inside: avoid }
caption { break-after: avoid }
.recall { break-inside: auto }  .recall .rh { break-after: avoid }
.band { break-after: avoid; break-inside: avoid }
.box, .diag, .q, figure, .keystrip { break-inside: avoid }
```

## SVG conventions

- `viewBox="0 0 1000 H"`, `style="width:100%;height:auto"`.
- `font-family="SSans"` on every `<text>`; sizes 11–22 in viewBox units.
- Rounded rects `rx="8"`; hairlines `stroke-width="1.2"`.
- Fills from the palette; tints for backgrounds, full strength for rules and text.
- **Linear gradients only.** `radialGradient` renders as nothing.
- Arrowheads as small `<path>` triangles — no `marker` elements.
