#!/usr/bin/env python3
"""
make_cards.py — STEP 5. Builds the flashcard deck from the finished chapters.

    python3 scripts/make_cards.py

Reads
    cards_config.json   chapter map + hand-written high-yield extras  (see below)
    src/1*.html         harvests EVERY <div class="recall"> ... <tr><td>Q</td><td>A</td>

Writes
    src/9_flashcards.html        the in-guide appendix (2-column, Q+A together)
    flashcards.html / .pdf       the cut-out deck, 12 per A4 sheet, duplex-mirrored
    flashcards_anki.tsv          Anki import

cards_config.json shape
{
  "doc_title":   "The Anemias",
  "subtitle":    "Part I",
  "footer":      "Dr. X · Minia University",
  "appendix_letter": "E",
  "chapters": {
    "src/10_ch1.html": [1, "Blood &amp; Haemoglobin", "#9B1B30"],
    "src/11_ch2.html": [2, "Definition &amp; Normals", "#14324F"]
  },
  "extras": [
    [13, "The Exam Case", "#6E1222",
     "Question text, may contain <b> and <i>.",
     "Answer text, may contain <b> and <i>."]
  ]
}
Order of "chapters" is the order the cards appear in. "extras" are appended to
their chapter and badged HY (high yield).
"""
import re, json, os, sys

CFG = json.load(open('cards_config.json', encoding='utf-8'))
CH = {k: tuple(v) for k, v in CFG['chapters'].items()}
ORDER = list(CFG['chapters'].keys())
AL = CFG.get('appendix_letter', 'E')


def clean(s):
    s = re.sub(r'<span class="chip[^"]*"[^>]*>.*?</span>', '', s, flags=re.S)
    s = re.sub(r'<span class="mini">(.*?)</span>', r'\1', s, flags=re.S)
    s = re.sub(r'<br\s*/?>', ' · ', s)
    s = re.sub(r'<(?!/?[bi]\b)[^>]+>', '', s)      # keep <b> and <i> only
    return re.sub(r'\s+', ' ', s).strip()


cards = []
for f in ORDER:
    num, title, col = CH[f]
    if not os.path.exists(f):
        sys.exit(f'cards_config.json points at a missing file: {f}')
    s = open(f, encoding='utf-8').read()
    for m in re.finditer(r'<div class="recall">(.*?)</table>', s, re.S):
        for q, a in re.findall(r'<tr><td>(.*?)</td><td>(.*?)</td></tr>', m.group(1), re.S):
            q, a = clean(q), clean(a)
            if q and a:
                cards.append({'ch': num, 'title': title, 'col': col, 'q': q, 'a': a})

for num, title, col, q, a in CFG.get('extras', []):
    cards.append({'ch': num, 'title': title, 'col': col, 'q': q, 'a': a, 'star': True})

cards.sort(key=lambda c: (c['ch'], c.get('star', False)))
for i, c in enumerate(cards, 1):
    c['n'] = i
N = len(cards)
NST = sum(1 for c in cards if c.get('star'))

# =============================================================== A. cut-out deck
def fs(t, base, small, tiny, l1=78, l2=140):
    n = len(re.sub(r'<[^>]+>', '', t))
    return base if n < l1 else (small if n < l2 else tiny)


def card_html(c, side):
    txt = c['q'] if side == 'f' else c['a']
    size = fs(txt, 9.8, 8.8, 7.9) if side == 'f' else fs(txt, 9.4, 8.5, 7.6)
    star = '<span class="star">HIGH YIELD</span>' if c.get('star') else ''
    cls = 'ctxt ans' if side == 'b' else 'ctxt'
    return (f'<div class="card {"back" if side=="b" else ""}" style="--cc:{c["col"]}">'
            f'<div class="chead"><span class="cch">CH {c["ch"]} · {c["title"]}</span>'
            f'{star}<span class="cnum">{c["n"]:03d}</span></div>'
            f'<div class="{cls}"><div class="inner" style="font-size:{size}pt">{txt}</div></div>'
            f'<div class="cfoot">{"ANSWER" if side=="b" else "QUESTION"}</div></div>')


PER, COLS = 12, 3
pages = [cards[i:i + PER] for i in range(0, N, PER)]
body = []
for pg in pages:
    body.append('<div class="sheet">')
    body += [card_html(c, 'f') for c in pg]
    body += ['<div class="card blank"></div>'] * (PER - len(pg))
    body.append('</div>')
    mirrored = []
    for r in range(0, PER, COLS):                 # mirror columns: long-edge duplex
        row = pg[r:r + COLS] + [None] * max(0, COLS - len(pg[r:r + COLS]))
        mirrored += row[::-1]
    body.append('<div class="sheet back-sheet">')
    body += [card_html(c, 'b') if c else '<div class="card blank"></div>' for c in mirrored]
    body.append('</div>')

DECK_CSS = """
@font-face{font-family:'SSerif';src:url('fonts/SourceSerif4-400.ttf');font-weight:400}
@font-face{font-family:'SSerif';src:url('fonts/SourceSerif4-600.ttf');font-weight:600}
@font-face{font-family:'SSerif';src:url('fonts/SourceSerif4-700.ttf');font-weight:700}
@font-face{font-family:'SSerif';src:url('fonts/SourceSerif4Italic-400.ttf');font-weight:400;font-style:italic}
@font-face{font-family:'SSans';src:url('fonts/SourceSans3-400.ttf');font-weight:400}
@font-face{font-family:'SSans';src:url('fonts/SourceSans3-600.ttf');font-weight:600}
@font-face{font-family:'SSans';src:url('fonts/SourceSans3-700.ttf');font-weight:700}
@page{size:A4;margin:14mm 13mm}
@page cover{margin:0}
*{box-sizing:border-box}
body{margin:0;font-family:'SSerif',serif;color:#1B2230}
.sheet{display:flex;flex-wrap:wrap;width:184mm;height:269mm;break-after:page}
.card{width:61.33mm;height:67.25mm;padding:3.4mm 3.6mm 2.8mm;border:.5pt dashed #C3CCD6;
  position:relative;overflow:hidden;display:flex;flex-direction:column}
.card.blank{border-color:#E8ECF0}
.chead{display:flex;align-items:center;gap:2mm;border-bottom:1.6pt solid var(--cc);
  padding-bottom:1.4mm;margin-bottom:2.6mm}
.cch{font-family:'SSans';font-size:6.6pt;font-weight:700;letter-spacing:.11em;
  text-transform:uppercase;color:var(--cc);flex:1;line-height:1.25}
.star{font-family:'SSans';font-size:5.6pt;font-weight:700;letter-spacing:.11em;color:#fff;
  background:#D9A521;padding:.5mm 1.4mm;border-radius:.6mm}
.cnum{font-family:'SSans';font-size:8.4pt;font-weight:700;color:#B6BFC9}
.ctxt{flex:1;display:flex;align-items:center}
.ctxt .inner{line-height:1.42;width:100%}
.card.back{background:#FAFBFC}
.cfoot{font-family:'SSans';font-size:5.6pt;font-weight:700;letter-spacing:.22em;
  color:#C3CCD6;text-transform:uppercase}
.card.back .cfoot{color:var(--cc);opacity:.55}
.cvr{page:cover;width:210mm;height:297mm;position:relative;color:#fff;break-after:page;
  background:linear-gradient(160deg,#6E1222 0%,#9B1B30 40%,#14324F 100%)}
.cvr .in{position:absolute;left:20mm;right:20mm;top:52mm}
.cvr .k{font-family:'SSans';font-size:9pt;letter-spacing:.3em;font-weight:600;color:#F3C9D0;
  text-transform:uppercase;margin-bottom:7mm}
.cvr h1{font-family:'SSans';font-weight:700;font-size:42pt;line-height:1.02;margin:0}
.cvr h1 span{display:block;font-weight:400;font-size:22pt;color:#F1C6CE;margin-top:3mm}
.cvr .r{width:32mm;height:2.4pt;background:#F3C9D0;margin:8mm 0 7mm}
.cvr .s{font-family:'SSans';font-size:11pt;line-height:1.65;color:#EAD6DA;max-width:120mm}
.cvr .b{position:absolute;left:20mm;right:20mm;bottom:22mm;padding-top:6mm;
  border-top:.6pt solid rgba(255,255,255,.3);font-family:'SSans';font-size:9.2pt;
  color:#E7D2D7;line-height:1.7}
.cvr .stats{position:absolute;left:20mm;right:20mm;bottom:52mm;display:flex;gap:4mm}
.cvr .st{flex:1;border:.8pt solid rgba(255,255,255,.4);border-radius:2mm;padding:3.4mm 4mm;
  font-family:'SSans'}
.cvr .st b{display:block;font-size:20pt;font-weight:700;color:#fff;line-height:1}
.cvr .st span{font-size:8pt;color:#EBCFD5;letter-spacing:.06em}
.howto{font-family:'SSans'}
.howto h2{font-size:15pt;color:#6E1222;margin:0 0 4mm}
.howto h3{font-size:10pt;color:#14324F;margin:6mm 0 2mm;letter-spacing:.06em;text-transform:uppercase}
.howto p,.howto ol{font-size:9.6pt;line-height:1.6;color:#2C3644}
.howto ol{padding-left:6mm} .howto li{margin-bottom:2mm}
.howto .warn{background:#FFF7E4;border-left:2.6pt solid #D9A521;padding:3mm 4mm;
  border-radius:1.4mm;font-size:9.4pt;line-height:1.55;margin:4mm 0}
"""

DECK = f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<title>{CFG['doc_title']} — Flashcards</title><style>{DECK_CSS}</style></head><body>
<div class="cvr"><div class="in">
 <div class="k">{CFG.get('kicker','Flashcard deck')}</div>
 <h1>Flashcards<span>{CFG['doc_title']} — {CFG.get('subtitle','')}</span></h1>
 <div class="r"></div>
 <div class="s">A cut-and-test deck built from the same sources as the study guide.
   Print double-sided, cut on the dashed lines, and test yourself out loud.</div></div>
<div class="stats">
 <div class="st"><b>{N}</b><span>CARDS</span></div>
 <div class="st"><b>{NST}</b><span>HIGH-YIELD</span></div>
 <div class="st"><b>{len(set(c['ch'] for c in cards))}</b><span>CHAPTERS</span></div>
 <div class="st"><b>12</b><span>PER SHEET</span></div></div>
<div class="b"><b>Companion to</b> {CFG['doc_title']}<br>{CFG['footer']}</div></div>

<div class="howto">
<h2>How to print and use this deck</h2>
<h3>Printing</h3>
<ol>
<li>Print <b>double-sided</b>, flipping on the <b>long edge</b> — the standard setting.</li>
<li>Set scaling to <b>100% / Actual size</b>. Never "fit to page", or fronts and backs drift.</li>
<li>The back sheets are already <b>column-mirrored</b>, so question 1 lands behind answer 1.</li>
<li>Cut along the dashed lines — 12 cards per sheet, 61 x 67 mm each.</li>
</ol>
<div class="warn"><b>Single-sided printer?</b> Print odd pages, reload, print even pages. Or fold
each card along the dashed line instead of cutting.</div>
<h3>Using them</h3>
<ol>
<li><b>Say the answer out loud</b> before turning the card.</li>
<li>One chapter colour at a time until clean, then shuffle chapters together.</li>
<li>Three piles: knew it · hesitated · missed it. Only the last two return tomorrow.</li>
<li>Keep the HIGH YIELD cards in circulation to the last day.</li>
</ol></div>
{''.join(body)}</body></html>"""
open('flashcards.html', 'w', encoding='utf-8').write(DECK)

# =============================================================== B. in-guide appendix
rows, cur = [], None
for c in cards:
    if c['ch'] != cur:
        cur = c['ch']
        rows.append(f'<div class="fcsec" style="--cc:{c["col"]}">'
                    f'<span class="fcn">CH {c["ch"]}</span>{c["title"]}</div>')
    star = '<span class="fcstar">HY</span>' if c.get('star') else ''
    rows.append(f'<div class="fc" style="--cc:{c["col"]}">'
                f'<div class="fcq"><span class="fcnum">{c["n"]:03d}</span>{star}{c["q"]}</div>'
                f'<div class="fca">{c["a"]}</div></div>')

APPENDIX = f"""
<!-- ============ APPENDIX {AL} · FLASHCARDS ============ -->
<div class="chapopen" style="border-bottom-color:var(--crimson)">
  <span class="chapnum">Appendix {AL}</span>
  <h1 class="chap">The Flashcard Deck</h1>
  <p class="chapsub">All {N} cards, question and answer together, compressed onto the page.</p>
</div>

<div class="keystrip">
  <div class="k"><span class="lbl">Cards</span><span class="val">{N}</span>
    <span class="cap">every rapid-recall row in this guide, plus {NST} curated additions</span></div>
  <div class="k"><span class="lbl">High-yield</span><span class="val">{NST}</span>
    <span class="cap">marked HY — the triads, the discriminators and the exam case</span></div>
  <div class="k"><span class="lbl">Grouped by</span><span class="val" style="font-size:11pt">Chapter</span>
    <span class="cap">colour-coded, numbered 001–{N}</span></div>
  <div class="k"><span class="lbl">Also supplied</span>
    <span class="val" style="font-size:10.4pt">Anki<br>+ cut-out</span>
    <span class="cap">see {AL}.2</span></div>
</div>

<div class="box clin"><span class="hd">How to run it</span>
<ol style="margin-bottom:0">
<li><b>Cover the grey answer line</b> with a sheet of paper, read the question, and
  <b>say the answer out loud</b> before you slide the paper down.</li>
<li>Work <b>one chapter colour at a time</b> until it is clean.</li>
<li>Then jump between chapters at random — mixing is what builds the differential-diagnosis
  reflex the exam actually tests.</li>
<li>Pencil a dot beside anything you miss. On the last pass read only the dots and the HY cards.</li>
</ol></div>

<h2 style="margin-top:6mm">{AL}.1 The deck</h2>
<div class="fcwrap">
{chr(10).join(rows)}
</div>

<h2>{AL}.2 Two companion files</h2>
<table class="tight">
<tr><th style="width:38%">File</th><th>What it is</th></tr>
<tr><td class="rowh">…_Flashcards.pdf</td>
  <td>The same {N} cards as a <b>cut-out deck</b> — 12 per sheet, 61 x 67 mm, question on the
    front and answer on the back. Print <b>double-sided, long-edge flip</b>, at
    <b>100% / Actual size</b>; the back sheets are already column-mirrored.</td></tr>
<tr><td class="rowh">…_anki.tsv</td>
  <td>The same {N} cards as a tab-separated file. In Anki: <i>File → Import</i>, separator
    <b>Tab</b>, allow HTML in fields, map column 1 → Front, 2 → Back, 3 → Tags.</td></tr>
</table>
"""
open('src/9_flashcards.html', 'w', encoding='utf-8').write(APPENDIX)

# =============================================================== C. Anki
def anki(t):
    return re.sub(r'\s+', ' ', t.replace('&amp;', '&').replace('&nbsp;', ' ')).strip()


with open('flashcards_anki.tsv', 'w', encoding='utf-8') as fh:
    fh.write('#separator:tab\n#html:true\n#tags column:3\n')
    for c in cards:
        tag = (f"Ch{c['ch']:02d} "
               + re.sub(r'[^A-Za-z0-9]+', '_', anki(c['title'])).strip('_'))
        if c.get('star'):
            tag += ' HighYield'
        fh.write(f"{anki(c['q'])}\t{anki(c['a'])}\t{tag}\n")

print(f'cards={N} high-yield={NST} sheets={len(pages)*2}')
print('wrote src/9_flashcards.html, flashcards.html, flashcards_anki.tsv')
print('NOTE: src/9_flashcards.html sorts LAST under the src/*.html glob — the deck')
print('      therefore always lands at the very end of the guide. Do not rename it.')
