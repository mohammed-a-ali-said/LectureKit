#!/usr/bin/env python3
"""
extract.py — STEP 1 of the pipeline.

Pulls the raw material out of the uploaded PDFs so you can read all of it
before writing a single line of the guide.

    python3 scripts/extract.py uploads/SLIDES.pdf uploads/BOOK.pdf

Writes:
    out/ppt_text.txt     slide-by-slide text of the FIRST pdf
    out/book_text.txt    page-by-page text of the SECOND pdf (optional)
    assets/s<slide>_<i>.png    every embedded image, at native resolution
    out/contact_<n>.png        contact sheets of those images, for visual triage

IMPORTANT
  * Check which uploaded file is actually which. Filenames lie. A 43-page
    960x540 landscape PDF is the slide deck; a 10-page portrait PDF with
    page numbers in the 80s is the book excerpt.
  * Import pymupdf, never fitz (fitz emits a deprecation warning).
"""
import sys, os, pymupdf
from PIL import Image

os.makedirs('out', exist_ok=True)
os.makedirs('assets', exist_ok=True)

args = sys.argv[1:]
if not args:
    sys.exit(__doc__)

# ---------------------------------------------------------------- identify
for p in args:
    d = pymupdf.open(p)
    r = d[0].rect
    kind = 'SLIDES (landscape)' if r.width > r.height else 'BOOK / portrait'
    print(f'{p}: {d.page_count} pages, {r.width:.0f}x{r.height:.0f} -> looks like {kind}')

# ---------------------------------------------------------------- text
labels = ['SLIDE', 'BOOKPAGE']
names = ['out/ppt_text.txt', 'out/book_text.txt']
for i, p in enumerate(args[:2]):
    d = pymupdf.open(p)
    with open(names[i], 'w', encoding='utf-8') as fh:
        for n in range(d.page_count):
            fh.write(f'\n=== {labels[i]} {n + 1} ===\n' + d[n].get_text())
    print('wrote', names[i])

# ---------------------------------------------------------------- images
d = pymupdf.open(args[0])
saved = []
for pno in range(d.page_count):
    for idx, info in enumerate(d[pno].get_images(full=True)):
        xref = info[0]
        try:
            pix = pymupdf.Pixmap(d, xref)
            if pix.n - pix.alpha >= 4:
                pix = pymupdf.Pixmap(pymupdf.csRGB, pix)
            if pix.width < 60 or pix.height < 60:      # icons / bullets
                continue
            out = f'assets/s{pno + 1}_{idx}.png'
            pix.save(out)
            saved.append(out)
        except Exception as e:
            print('  skip', pno + 1, idx, e)
print(f'saved {len(saved)} images to assets/')

# ---------------------------------------------------------------- contact sheets
PER, COLS, TH = 24, 6, 300
for b in range(0, len(saved), PER):
    chunk = saved[b:b + PER]
    rows = (len(chunk) + COLS - 1) // COLS
    sheet = Image.new('RGB', (COLS * TH, rows * (TH + 18)), '#F2F4F7')
    for i, f in enumerate(chunk):
        im = Image.open(f).convert('RGB')
        im.thumbnail((TH - 8, TH - 8))
        x, y = (i % COLS) * TH, (i // COLS) * (TH + 18)
        sheet.paste(im, (x + 4, y + 4))
    name = f'out/contact_{b // PER}.png'
    sheet.save(name)
    print('wrote', name, '  <- READ THIS FILE, then decide which images to keep')
