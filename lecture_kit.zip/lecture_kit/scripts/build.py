#!/usr/bin/env python3
"""
build.py — STEP 4 of the pipeline. Renders, compresses and proofs the guide.

    python3 scripts/build.py                 # render + compress + contact sheets
    python3 scripts/build.py --no-proof      # render + compress only (faster)

Concatenation order is FIXED and must not be changed:
    src/00_head.html  src/01_front.html  src/02_map.html
    src/1*.html   (chapters)   src/2*.html  (appendices)   src/9*.html  (flashcards, last)
A plain `cat src/*.html` is WRONG: once files named 2*.html exist, glob order
puts 22_ before 10_ in some shells. Always use the explicit form below.

What it does
    1. concatenates the chunks and appends </body></html>
    2. renders with WeasyPrint at A4
    3. subsets fonts + deflates streams with pymupdf  (typically halves the file)
    4. exports every page to out/p##.png and builds contact sheets out/sheet#.png
       -> YOU MUST READ THOSE SHEETS and fix any layout defect before delivering
"""
import glob, os, shutil, subprocess, sys

TITLE = os.environ.get('GUIDE_NAME', 'Study_Guide')
HTML_OUT = 'guide.html'
PDF_OUT = f'{TITLE}.pdf'
PROOF = '--no-proof' not in sys.argv

# ---------------------------------------------------------------- 1. concat
order = ['src/00_head.html', 'src/01_front.html', 'src/02_map.html']
order += sorted(glob.glob('src/1*.html'))
order += sorted(glob.glob('src/2*.html'))
order += sorted(glob.glob('src/9*.html'))      # flashcard appendix always last
missing = [f for f in order[:3] if not os.path.exists(f)]
if missing:
    sys.exit(f'missing required chunk(s): {missing}')

with open(HTML_OUT, 'w', encoding='utf-8') as out:
    for f in order:
        out.write(open(f, encoding='utf-8').read())
    out.write('\n</body></html>\n')
print('concatenated', len(order), 'chunks ->', HTML_OUT)
for f in order:
    print('   ', f)

# ---------------------------------------------------------------- 2. render
from weasyprint import HTML
HTML(HTML_OUT, base_url=os.getcwd() + '/').write_pdf(PDF_OUT)
raw = os.path.getsize(PDF_OUT)

# ---------------------------------------------------------------- 3. compress
import pymupdf
d = pymupdf.open(PDF_OUT)
pages = d.page_count
try:
    d.subset_fonts(verbose=False)
except Exception as e:
    print('   font subsetting unavailable:', e)
d.save(PDF_OUT + '.tmp', garbage=4, deflate=True, deflate_fonts=True, clean=True)
d.close()
if os.path.getsize(PDF_OUT + '.tmp') < raw:
    shutil.move(PDF_OUT + '.tmp', PDF_OUT)
else:
    os.remove(PDF_OUT + '.tmp')
print(f'rendered {PDF_OUT}: {pages} pages, '
      f'{raw/1e6:.2f} MB -> {os.path.getsize(PDF_OUT)/1e6:.2f} MB')

# ---------------------------------------------------------------- size alarm
if os.path.getsize(PDF_OUT) / max(pages, 1) > 90_000:
    print('\n  !! WARNING: >90 KB per page. Usual causes, in order of likelihood:')
    print('     1. a CSS `dotted` or `dashed` border on a repeated element')
    print('        (WeasyPrint draws every dot as a separate path — this can add MBs).')
    print('        Use `solid` hairlines instead.')
    print('     2. figures still saved as .png — convert photographs to .jpg q90.')

# ---------------------------------------------------------------- 4. proof
if PROOF:
    from PIL import Image
    for f in glob.glob('out/p*.png') + glob.glob('out/sheet*.png'):
        os.remove(f)
    os.makedirs('out', exist_ok=True)
    d = pymupdf.open(PDF_OUT)
    for i in range(d.page_count):
        d[i].get_pixmap(dpi=76).save(f'out/p{i:02d}.png')
    fs = sorted(glob.glob('out/p*.png'))
    w, h = Image.open(fs[0]).size
    PER, COLS = 18, 6
    for b in range(0, len(fs), PER):
        chunk = fs[b:b + PER]
        rows = (len(chunk) + COLS - 1) // COLS
        s = Image.new('RGB', (COLS * w, rows * h), '#BBBBBB')
        for i, f in enumerate(chunk):
            s.paste(Image.open(f), ((i % COLS) * w, (i // COLS) * h))
        s.thumbnail((2300, 2300))
        s.save(f'out/sheet{b // PER}.png')
    print(f'proof sheets: out/sheet0..{(len(fs)-1)//PER}.png '
          f'and single pages out/p##.png')
    print('\n  -> READ EVERY SHEET before delivering. Look for:')
    print('     near-empty pages · orphaned headings or captions · figures')
    print('     overflowing the text block · tables split badly · widow answer keys.')
