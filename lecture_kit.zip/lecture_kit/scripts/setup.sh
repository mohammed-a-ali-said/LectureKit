#!/usr/bin/env bash
# ============================================================================
#  setup.sh — run ONCE at the start of every session.
#  Installs the renderer and downloads + instances the exact fonts.
#  Sandbox package installs do NOT persist between sessions: if any script
#  later dies with ModuleNotFoundError, just run this file again.
# ============================================================================
#
#  RUN IT FROM THE PROJECT ROOT, not from inside lecture_kit/:
#      bash lecture_kit/scripts/setup.sh
#  It deliberately does NOT cd — fonts/, src/, fig/ must be created next to
#  lecture_kit/, because every path in the CSS and the scripts is relative to
#  the project root.
set -e

if [ -d "lecture_kit" ] || [ -f "INSTRUCTIONS.md" ]; then
  if [ -f "INSTRUCTIONS.md" ]; then
    echo "ERROR: you are inside lecture_kit/. cd to the project root and run:"
    echo "       bash lecture_kit/scripts/setup.sh"
    exit 1
  fi
fi

echo "== 1/3  python packages =="
pip install --quiet weasyprint pymupdf pillow fonttools
python3 - <<'PY'
import weasyprint, pymupdf, PIL
print('   weasyprint', weasyprint.__version__, '| pymupdf', pymupdf.__doc__.split()[1] if pymupdf.__doc__ else '?', '| pillow', PIL.__version__)
PY

echo "== 2/3  fonts =="
# Source Serif 4 + Source Sans 3, downloaded as VARIABLE fonts then frozen to
# STATIC instances. WeasyPrint's variable-font support is unreliable — always
# instance them. Skip if they are already present.
mkdir -p fonts
if [ ! -f fonts/SourceSerif4-400.ttf ]; then
  BASE="https://github.com/google/fonts/raw/main/ofl"
  curl -sL -o fonts/SRF-VF.ttf  "$BASE/sourceserif4/SourceSerif4%5Bopsz,wght%5D.ttf"
  curl -sL -o fonts/SRFi-VF.ttf "$BASE/sourceserif4/SourceSerif4-Italic%5Bopsz,wght%5D.ttf"
  curl -sL -o fonts/SS3-VF.ttf  "$BASE/sourcesans3/SourceSans3%5Bwght%5D.ttf"
  curl -sL -o fonts/SS3i-VF.ttf "$BASE/sourcesans3/SourceSans3-Italic%5Bwght%5D.ttf"

  python3 - <<'PY'
from fontTools.ttLib import TTFont
from fontTools.varLib import instancer
JOBS = [
    ('fonts/SRF-VF.ttf',  {'opsz': 11}, 'SourceSerif4',       [400, 600, 700]),
    ('fonts/SRFi-VF.ttf', {'opsz': 11}, 'SourceSerif4Italic', [400, 600]),
    ('fonts/SS3-VF.ttf',  {},           'SourceSans3',        [400, 600, 700]),
    ('fonts/SS3i-VF.ttf', {},           'SourceSans3Italic',  [400, 600]),
]
for src, pins, name, weights in JOBS:
    for w in weights:
        f = TTFont(src)
        instancer.instantiateVariableFont(f, {**pins, 'wght': w}, inplace=True)
        out = f'fonts/{name}-{w}.ttf'
        f.save(out)
        print('   ', out)
PY
else
  echo "   fonts already present — skipped"
fi

echo "== 3/3  folders =="
mkdir -p src fig assets uploads out
echo "   ready."
echo
echo "NOTE: no emoji font exists in this sandbox. Never put an emoji in the HTML."
